library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity lap_timer is
    generic (
        CLK_FREQ            : integer := 100_000_000
    );
    Port ( 
        clk_i               : in std_logic;
        btn_i               : in std_logic_vector(4 downto 0);
        secs_o              : out std_logic_vector (7 downto 0);
        min_o               : out std_logic_vector (7 downto 0);
        row_array_o         : out std_logic_vector (3 downto 0);
        lap_disp            : out std_logic := '0';
        hours_o             : out std_logic_vector (7 downto 0)
        );
end lap_timer;

architecture Behavioral of lap_timer is

constant timer_lim              : integer := CLK_FREQ - 1;
signal timer                    : integer range 0 to CLK_FREQ := 0;
signal tick                     : std_logic := '0';

type t_vector_type is array (0 to 9) of unsigned(7 downto 0);
signal hours_array      : t_vector_type := (others => (others => '0'));
signal minute_array     : t_vector_type := (others => (others => '0'));
signal secs_array       : t_vector_type := (others => (others => '0'));
signal temp_row_array   : unsigned (3 downto 0) := "0000";

signal secs                     : integer range 0 to 60 := 0;
signal minutes                  : integer range 0 to 59 := 0;
signal hours                    : integer range 0 to 99 := 0;

signal secs_lap                 : integer range 0 to 60 := 0;
signal minutes_lap              : integer range 0 to 59 := 0;
signal hours_lap                : integer range 0 to 99 := 0;

signal toggle                   : std_logic := '0';
signal temp_lap_disp            : std_logic := '0';
begin

P_BTN : process(btn_i(0)) begin
    if (btn_i(0) = '1') then
        toggle <= not(toggle);
    end if;


end process;

P_COUNT : process(clk_i) begin
if (rising_edge(clk_i)) then
    if (timer >= timer_lim) then
        timer <= 0;
        tick <= '1';
    else 
        tick <= '0';
        timer <= timer + 1;
    end if;

end if;
end process;

P_COUNTER_MAIN : process(clk_i) begin
if (rising_edge(clk_i)) then

    if(btn_i(1) = '0') then
        secs    <= 0;
        minutes <= 0;
        hours   <= 0;
    else
        if(toggle = '1') then
            if (secs = 59) then
                secs <= 0;
                if (minutes = 59) then
                    minutes <= 0;
                    if hours = 23 then
                        hours <= 0;
                    else
                        hours <= hours + 1;
                    end if;
                else
                    minutes <= minutes + 1;
                end if;
            else
                secs <= secs + 1;
            end if;
        end if;
    end if;
end if;
end process;


P_COUNTER_LAP : process(clk_i) begin
if (rising_edge(clk_i)) then
    
    if(btn_i(1) = '0') then

        secs_lap     <= 0;
        minutes_lap  <= 0;
        hours_lap    <= 0;
        temp_row_array <= 0;
        hours_array  <= (others => (others => '0'));
        minute_array <= (others => (others => '0'));
        secs_array   <= (others => (others => '0'));

    elsif(btn_i(2) = '1') then

        hours_array(to_integer(temp_row_array))     <= hours_lap;
        minute_array(to_integer(temp_row_array))    <= minutes_lap;
        secs_array(to_integer(temp_row_array))      <= secs_lap;

        if (temp_row_array < 9) then
            temp_row_array <= temp_row_array + 1;
        end if;

        secs_lap    <= 0;
        minutes_lap <= 0;
        hours_lap   <= 0;
    
    elsif (btn_i(2) = '1' and toggle = '0') then

    elsif (btn_i(3) = '1' and toggle = '0') then
        
    elsif (btn_i(4) = '1' and toggle = '0') then

    else

        if(toggle = '1') then
            if (secs_lap = 59) then
                secs_lap <= 0;
                if (minutes_lap = 59) then
                    minutes_lap <= 0;
                    if hours_lap = 23 then
                        hours_lap <= 0;
                    else
                        hours_lap <= hours_lap + 1;
                    end if;
                else
                    minutes_lap <= minutes_lap + 1;
                end if;
            else
                secs_lap <= secs_lap + 1;
            end if;
        end if;

    end if;
end if;
end process;



row_array_o         <= std_logic_vector(temp_row_array);
count_val_o <= std_logic_vector(results_array(to_integer(temp_row_array)));

end Behavioral;
