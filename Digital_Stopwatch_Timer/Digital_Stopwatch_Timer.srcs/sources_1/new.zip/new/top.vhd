library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top is
    generic(
        CLK_FREQ : integer := 100_000_000 
    );
    Port ( 
        clk_i          : in  std_logic;
        btn_i          : in  std_logic_vector (4 downto 0);
        sw_mode_i      : in  std_logic_vector (1 downto 0);
        anodes_o       : out std_logic_vector(7 downto 0);
        led_o          : out std_logic_vector (15 downto 0);
        sevenseg_o     : out std_logic_vector (7 downto 0)
    );
end top;

architecture Behavioral of top is

    -- Component tanımları (Aynen kalabilir, aşağıda instantiations kısmını düzelttim)
    component stopwatch is
        generic( CLK_FREQ : integer );
        Port ( 
            clk_i      : in std_logic;
            btn_i      : in std_logic_vector(1 downto 0); 
            sec_o      : out std_logic_vector(7 downto 0);
            min_o      : out std_logic_vector(7 downto 0);
            hours_o    : out std_logic_vector(7 downto 0)
        );
    end component;

    component rise_fall_deb is
        generic ( clk_freq : integer; stable_time : integer );
        port (
            clk : in std_logic; 
            button_in : in std_logic;
            button_out : out std_logic; 
            rising_pulse : out std_logic; 
            falling_pulse : out std_logic
        );
    end component;

    component display is
        generic( CLK_FREQ : integer );
        Port (  
            clk_i           : in std_logic;
            secs_i          : in std_logic_vector (7 downto 0);
            minutes_i       : in std_logic_vector (7 downto 0);
            hours_i         : in std_logic_vector (7 downto 0);
            anodes_o        : out std_logic_vector (7 downto 0);
            sevenseg_o      : out std_logic_vector (7 downto 0)     
        );
    end component;

    component countdown is
        generic( CLK_FREQ : integer );
        Port ( 
            clk_i          : in  std_logic;
            btn_i          : in  std_logic_vector (4 downto 0);
            led_o          : out std_logic_vector (15 downto 0);
            sec_o          : out std_logic_vector (7 downto 0);
            min_o          : out std_logic_vector (7 downto 0);
            hours_o        : out std_logic_vector (7 downto 0)
        );
    end component;

    component clock is
        generic ( CLK_FREQ : integer );
        Port ( 
            clk_i       : in std_logic;
            btn_i       : in std_logic_vector(4 downto 0);
            led_o       : out std_logic_vector(1 downto 0);
            sec_o       : out std_logic_vector(7 downto 0);        
            min_o       : out std_logic_vector(7 downto 0);
            hours_o     : out std_logic_vector(7 downto 0)
        );
    end component;

    signal s_btn_pulses       : std_logic_vector(4 downto 0);
    signal s_btns_stopwatch   : std_logic_vector(1 downto 0);
    signal s_btns_countdown   : std_logic_vector(4 downto 0);
    signal s_btns_clock       : std_logic_vector(4 downto 0);
    
    signal s_secs_stop, s_mins_stop, s_hours_stop : std_logic_vector(7 downto 0);
    signal s_secs_count, s_mins_count, s_hours_count : std_logic_vector(7 downto 0);
    signal s_secs_clock, s_mins_clock, s_hours_clock : std_logic_vector(7 downto 0);
    signal s_secs_mux, s_mins_mux, s_hours_mux : std_logic_vector(7 downto 0);
    
    signal s_leds_countdown : std_logic_vector(15 downto 0);
    signal s_leds_clock     : std_logic_vector(1 downto 0);

begin

    GEN_DEBOUNCE: for i in 0 to 4 generate
        deb_inst : rise_fall_deb
        generic map ( clk_freq => CLK_FREQ, stable_time => 10 )
        port map (
            clk           => clk_i,
            button_in     => btn_i(i),     
            button_out    => open,
            rising_pulse  => s_btn_pulses(i), 
            falling_pulse => open
        );
    end generate;

    -- Buton Dağıtım Mantığı (Latch oluşmaması için tüm sinyaller her durumda atanmalı)
    process(sw_mode_i, s_btn_pulses)
    begin
        -- Default değerler (Reset durumları)
        s_btns_stopwatch <= "10"; -- Kronometreyi durdur/sıfırla
        s_btns_countdown <= (others => '0');
        s_btns_clock     <= (others => '0');

        if (sw_mode_i = "00") then -- STOPWATCH MODE
            s_btns_stopwatch <= s_btn_pulses(1 downto 0);
            s_btns_countdown(1) <= '1'; -- Diğer modları resetle
            
        elsif (sw_mode_i = "01") then -- COUNTDOWN MODE
            s_btns_countdown <= s_btn_pulses;
            s_btns_stopwatch <= "10";

        elsif (sw_mode_i = "10") then -- CLOCK MODE
            s_btns_clock <= s_btn_pulses(4 downto 0);
            s_btns_stopwatch <= "10";
        end if;
    end process;

    inst_stopwatch : stopwatch
    generic map ( CLK_FREQ => CLK_FREQ )
    port map (
        clk_i   => clk_i,
        btn_i   => s_btns_stopwatch, 
        sec_o   => s_secs_stop,  
        min_o   => s_mins_stop,  
        hours_o => s_hours_stop 
    );

    insta_countdown : countdown
    generic map ( CLK_FREQ => CLK_FREQ ) 
    port map ( 
        clk_i       => clk_i,          
        btn_i       => s_btns_countdown, 
        led_o       => s_leds_countdown,   
        sec_o       => s_secs_count,   
        min_o       => s_mins_count,   
        hours_o     => s_hours_count   
    );

    inst_clock : clock
    generic map ( CLK_FREQ => CLK_FREQ ) 
    port map ( 
        clk_i       => clk_i,          
        btn_i       => s_btns_clock,
        led_o       => s_leds_clock,
        sec_o       => s_secs_clock,
        min_o       => s_mins_clock,
        hours_o     => s_hours_clock
    );

    -- Çıkış Mux Mantığı (Display ve LED)
    process(sw_mode_i, s_secs_stop, s_mins_stop, s_hours_stop, 
            s_secs_count, s_mins_count, s_hours_count,
            s_secs_clock, s_mins_clock, s_hours_clock,
            s_leds_countdown, s_leds_clock)
    begin
        case sw_mode_i is
            when "00" => -- Stopwatch
                s_secs_mux  <= s_secs_stop;
                s_mins_mux  <= s_mins_stop;
                s_hours_mux <= s_hours_stop;
                led_o       <= (others => '0');
            when "01" => -- Countdown
                s_secs_mux  <= s_secs_count;
                s_mins_mux  <= s_mins_count;
                s_hours_mux <= s_hours_count;
                led_o       <= s_leds_countdown;
            when "10" => -- Clock
                s_secs_mux  <= s_secs_clock;
                s_mins_mux  <= s_mins_clock;
                s_hours_mux <= s_hours_clock;
                led_o       <= (15 downto 2 => '0') & s_leds_clock;
            when others =>
                s_secs_mux  <= (others => '0');
                s_mins_mux  <= (others => '0');
                s_hours_mux <= (others => '0');
                led_o       <= (others => '0');
        end case;
    end process;

    inst_main_display : display
    generic map ( CLK_FREQ => CLK_FREQ )
    port map (
        clk_i       => clk_i,
        secs_i      => s_secs_mux, 
        minutes_i   => s_mins_mux, 
        hours_i     => s_hours_mux,
        anodes_o    => anodes_o,
        sevenseg_o  => sevenseg_o  
    );

end Behavioral;